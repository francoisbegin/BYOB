package ca.franky.byob;

import java.io.IOException;
import java.math.BigInteger;

import jpcap.JpcapCaptor;
import jpcap.NetworkInterface;
import jpcap.packet.Packet;

public class ClientListenOnICMPChannel extends Thread {

	public void run() {
		System.out.println("the thread program was called");
		while (true) {
			try {
				NetworkInterface[] devices = JpcapCaptor.getDeviceList();
	 			JpcapCaptor captor=JpcapCaptor.openDevice(devices[2], 65535, false, 20);
	 			//We capture inly icmp packets
	 			captor.setFilter("icmp", true);
	 			while(true){
	 				//If our packet is not null, we capture it and print it out (convert to ascii)
	 				Packet myCapturedPacket = captor.getPacket();
	 					if ( myCapturedPacket != null ) {
	 					  	//System.out.println("Received a packet. Here are the details: "+myCapturedPacket);
	 					  	
	 					  	/*
	 					  	 * The last two bytes of the header contain the ISN (in bytes, so we need to convert the value to decimal)
	 					  	 */
	 					  	byte[] packetISNinBytes = new byte[]{myCapturedPacket.header[40],myCapturedPacket.header[41]};
	 					  	BigInteger bi = new BigInteger(packetISNinBytes);
	 					  	String packetISN = bi.toString();
	 					  	System.out.println("ISN="+packetISN);
	 					  		 					  	
	 					  	String myPacketDataString = "";
	 					  	int pos = 0;
	 					  	for ( byte b : myCapturedPacket.data ) {
	 					  		int i = (int) b;
	 					  		char c = (char)i;
	 					  		String asciiChar =  Character.toString(c);
	 					  		myPacketDataString += asciiChar;
	 					  		pos++;
	 					  		
	 					  	}
	 					  	if ( myPacketDataString.indexOf("#%$&") > -1) {
	 					  		System.out.println("I am being sent command # "+ packetISN.substring(packetISN.length()-1));
	 					  	}
	 					  	System.out.println(myPacketDataString);
	 				  }
	 			}
	 			
	 			
	 		} catch (IOException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}		
		}
    }
		
}
