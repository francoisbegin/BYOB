public class MyThread extends Thread {
    boolean pleaseWait = false;
    String momo = null;

    // This method is called when the thread runs
    public void run() {
        while (true) {
            momo += "a";

            // Check if should wait
            synchronized (this) {
                while (pleaseWait) {
                    try {
                        wait();
                    } catch (Exception e) {
                    }
                }
            }

            // Do work
        }
    }
}
