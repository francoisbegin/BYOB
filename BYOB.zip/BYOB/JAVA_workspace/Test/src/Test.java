
public class Test {
	
	public static void main(String[] args) {
		// Create and start the thread
		MyThread thread = new MyThread();
		thread.start();

		while (true) {
		    System.out.println("About to pause thread");

		    // Pause the thread
		    synchronized (thread) {
		        thread.pleaseWait = true;
		    }

		    System.out.println("Paused thread");

		    // Resume the thread
		    synchronized (thread) {
		        thread.pleaseWait = false;
		        thread.notify();
		    }
		    
		    System.out.println(thread.momo);
		    
		    System.out.println("Sleep");
		    
		    try {
    			Thread.sleep(5000 );
    		} catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

		    System.out.println("Re-started");
		}
		
	}



}
