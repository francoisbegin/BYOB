	import javax.xml.parsers.SAXParser;
	import javax.xml.parsers.SAXParserFactory;
	 
	import org.xml.sax.Attributes;
	import org.xml.sax.SAXException;
	import org.xml.sax.helpers.DefaultHandler;


public class xmlparser {

	static String victimAddress;
	static String victimFirstName;
	static String victimLastName;
	static String emailFromAddress;
	static String emailSubject;
	static String emailBody;
	
	 public static void main(String[] args) {
		 
		  try {
		 
		     SAXParserFactory factory = SAXParserFactory.newInstance();
		     SAXParser saxParser = factory.newSAXParser();
		 
		     DefaultHandler handler = new DefaultHandler() {
		 
		     boolean bvictdetails = false;
		     boolean bemaildetails = false;
		     boolean baddr = false;
		     boolean bfname = false;
		     boolean blname = false;
		     boolean bsubject = false;
		     boolean bfromaddr = false;
		     boolean bbody = false;
		 
		     public void startElement(String uri, String localName,
		        String qName, Attributes attributes)
		        throws SAXException {
		 
		        //System.out.println("Start Element :" + qName);
		 
		        if (qName.equalsIgnoreCase("victimDetails")) {
		        	bvictdetails = false;
		        }
		        
		        if (qName.equalsIgnoreCase("emailDetails")) {
		        	bemaildetails = false;
		        }
		        
		        if (qName.equalsIgnoreCase("address")) {
		           baddr = true;
		        }
		 
		        if (qName.equalsIgnoreCase("firstName")) {
			           bfname = true;
			        }
		        
		        if (qName.equalsIgnoreCase("lastName")) {
		           blname = true;
		        }
		 
		        if (qName.equalsIgnoreCase("subject")) {
		           bsubject = true;
		        }
		 
		        if (qName.equalsIgnoreCase("fromAddress")) {
		        	bfromaddr = true;
		        }
		 
		        if (qName.equalsIgnoreCase("body")) {
		        	bbody = true;
		        }
		     }
		 
		     public void endElement(String uri, String localName,
		          String qName)
		          throws SAXException {
		 
		    	  if (qName.equalsIgnoreCase("victimDetails")) {
			        	bvictdetails = true;
			        }
		    	  
		    	  if (qName.equalsIgnoreCase("emailDetails")) {
			        	bemaildetails = true;
			        }
		         
		 
		     }
		 
		     public void characters(char ch[], int start, int length)
		         throws SAXException {
		 
		    	if (bvictdetails) {
		    		System.out.println(emailSubject+"|||"+emailFromAddress+"|||"+emailBody);
		    		 System.out.println("Victim details: " +victimAddress+","+victimFirstName+","+victimLastName);
		    		 System.out.println("-------------------------------");
		    		 bvictdetails = false;
		    	}
		    	 
		    	//if (bemaildetails) {
		    	//	 System.out.println("email details: " +emailSubject+"|||"+emailFromAddress+"|||"+emailBody);
		    	//	 bemaildetails = false;
		    	//}
		    	
		    	 if (baddr) {
			            victimAddress = new String(ch, start, length);
			            baddr = false;
			     }
		    	 
		         if (bfname) {
		            victimFirstName = new String(ch, start, length);
		            bfname = false;
		          }
		 
		          if (blname) {
		              victimLastName = new String(ch, start, length);
		              blname = false;
		           }
		 
		          if (bsubject) {
		              emailSubject = new String(ch, start, length);
		              bsubject = false;
		           }
		 
		          if (bfromaddr) {
		              emailFromAddress = new String(ch, start, length);
		              bfromaddr = false;
		           }
		          
		          if (bbody) {
		              emailBody = new String(ch, start, length);
		              bbody = false;
		           }
		 
		        }
		 
		      };
		 
		      saxParser.parse("/home/fbegin1/Dropbox/BYOB-files/test.xml", handler);
		      //
		      // Create array list of email addresses and names so this can be an object that 'stands on its own'
		      //System.out.println(emailSubject+"|||"+emailFromAddress+"|||"+emailBody);
		 
		    } catch (Exception e) {
		      e.printStackTrace();
		    }
		  }
	 
	
	
	
	
}
