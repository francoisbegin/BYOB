<?PHP

/*
 * A Function tp help sort a multidimensional array using a particular key
 */
function subval_sort($a,$subkey) {
        foreach($a as $k=>$v) {
                $b[$k] = strtolower($v[$subkey]);
        }
        asort($b);
        foreach($b as $k=>$v) {
                $c[] = $a[$k];
        }
        return $c;
}


/*
 * A function that create a row in an HTML table according to a certain style
 *	First argument 		= font style
 *	2nd argument 		= background color of row
 *	Subsequent arguments 	= the row data
 */

function FormatRow () {

	$RowStyle= func_get_arg(0);
	$RowColor = func_get_arg(1);

	if (func_num_args() == 0) {
		return false;
	} else {

		switch ( func_get_arg(1) ) 
		{
			case "white";
				$color="#FFFFFF";
				break;
			case "lightgray";
				$color="#C0C0C0";
				break;
			case "lightyellow";
				$color="#FFFFCC";
				break;
			case "midyellow";
				$color="#FFFF66";
				break;
			case "brightyellow";
				$color="#FFFF00";
				break;
		}
			
		echo "<tr bgcolor=\"".$color."\">";
		
		for ($i =2; $i < func_num_args(); $i++) {
			$x = func_get_arg($i);
			switch ( func_get_arg(0) ) 
			{
				case "bold";
					echo "<td><strong>".$x."</strong></td>";
					break;
				case "normal";
					echo "<td>".$x."</td>";
					break;
			}


		}
		
		echo "</tr>";

		return;
	}			
}

// Function to get a specific C&C parameter from the the database
function getDBParam($paramName) {
	$query="SELECT paramValue FROM params WHERE paramName='$paramName'";
	$result=mysql_query($query);
	$row = mysql_fetch_array( $result ) ;
	return $row[0];
}

// Function to update a specific C&C parameter in the the database
function updateDBParam($paramName, $paramValue) {
	$query="UPDATE params SET paramValue='$paramValue' WHERE paramName='$paramName'";
	mysql_query($query);
}

// Function to create a dropdown from an array, with a specifc value being selected
function createDropdownFromList($list, $selectedValue,$name) {
	echo "<select name=\"".$name."\">";
	foreach ( $list as $currentValue ) {
		if ( $currentValue === $selectedValue ) {
			echo "<option selected=\"yes\" value=\"".$currentValue."\">".$currentValue."</option>";
		} else {
			echo "<option value=\"".$currentValue."\">".$currentValue."</option>";
		}
	}	
	echo "</select>";
}

?>
